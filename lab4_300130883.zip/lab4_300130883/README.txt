Student name: Anthony Zhao
Student number: 300130883
Course code: ITI1121
Lab section: C-4

This archive contains the 6 files of lab 4, that is, this file (README.txt),
plus the files Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.