public interface Series {

    public abstract double next();
    
}