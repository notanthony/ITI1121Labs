import java.util.*;
public class Q6{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		double[] arr = new double[10];
		for (int x =0; x< 10; x++) {
			arr[x] = sc.nextDouble();
		}	
		System.out.println(calculateAverage(arr));
		System.out.println(calculateMedian(arr));
		System.out.println(calculateNumberFailed(arr));
		System.out.println(calculateNumberPassed(arr));
	}

	public static double calculateAverage(double[] notes){
		double avg = 0;
		for (double mark: notes) {
			avg += mark;
		}
		return avg/notes.length;
	}

	public static double calculateMedian(double[] notes){
		Arrays.sort(notes);	
		if (notes.length%2 == 1){
			return notes[(notes.length-1)/2];
		}
		return (notes[notes.length/2]+notes[notes.length/2-1])/2; 
	}
	
	public static int calculateNumberFailed(double[] notes){
		Arrays.sort(notes);	
		int counter = 0;
		for (double mark: notes) {
			if (mark < 50) {
				counter++;
			} else {
				break;
			}
		}
		return counter;
	}

	public static int calculateNumberPassed(double[] notes){
		Arrays.sort(notes);	
		int counter = notes.length;
		for (double mark: notes) {
			if (mark < 50) {
				counter--;
			} else {
				break;
			}
		}
		return counter;
	}

}