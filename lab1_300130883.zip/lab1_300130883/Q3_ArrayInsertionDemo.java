public class Q3_ArrayInsertionDemo{

	public static int[] insertIntoArray(int[] beforeArray, int indexToInsert, int valueToInsert){
		int[] arr = new int[beforeArray.length+1];
		arr[indexToInsert] = valueToInsert;
		int counter =0;
		for (int x = 0; x < beforeArray.length; x++) {
			if (x == indexToInsert && beforeArray.length != 0) {
				counter++;
			}	
			arr[x+counter] = beforeArray[x];
		}
		
		return arr;
	}
	
	private static void print(int[] arr) {
		for (int num: arr) 
			System.out.println(num);
		System.out.println();
	}
	
	public static void main(String[] args) {
		int indexToInsert = 0;
		int valueToInsert = 0;
		int [] beforeArray = new int[10];
		System.out.println("Array before insertion:");
		print(beforeArray); 
		System.out.println("Array after insertion of " + valueToInsert + " at position " + indexToInsert + ":");
		print(insertIntoArray(beforeArray, indexToInsert, valueToInsert));
	}
}