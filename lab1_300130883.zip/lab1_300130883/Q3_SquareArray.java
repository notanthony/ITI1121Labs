public class Q3_SquareArray{

	public static int[] createArray(int size) {
		int[] arr = new int[size];
		for (int x = 0; x < size;x++) {
			arr[x] = x*x;
		}
		return arr;
	}

	public static void main(String[] args){

		for (int square : createArray(12)) {
			System.out.println("The square of "+(int)Math.sqrt(square)+" is:"+ square);
		}
	}
}