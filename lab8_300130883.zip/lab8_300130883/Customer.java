import java.util.*;
public class Customer{
  private int arrivalTime;
  private int numberOfItems;
  private int numberOfServedItems;
  private static final int MAX_NUM_ITEMS = 20;
  private Random generator = new Random();

  public Customer(int time){
    arrivalTime = time;
	numberOfServedItems = 0;
    numberOfItems = generator.nextInt(MAX_NUM_ITEMS-1)+1;
  }
  public int getArrivalTime(){
    return arrivalTime;
  }
  public int getNumberOfItems(){
    return numberOfItems;
  }
  public int getNumberOfServedItems(){
    return numberOfServedItems;
  }
  public void serve(){
    numberOfItems--;
	numberOfServedItems++;
  }
}
