import java.util.*;

public class Cashier{
  private Queue<Customer> queue;
  private Customer currentCustomer;
  private int waitTime;
  private int customersServed;
  private int itemsServed;
  
  public Cashier(){
    queue = new ArrayQueue<Customer>();
    itemsServed = 0;
    customersServed = 0;
    waitTime = 0;
    currentCustomer = null;
  }
  public void addCustomer(Customer c){
    queue.enqueue(c);
  }
  public int getQueueSize(){
    return queue.size();
  }
  
  public void serveCustomers(int currentTime){
    if(currentCustomer == null){
      try{
        currentCustomer = queue.dequeue();
      }
      catch(NoSuchElementException e){
        return;
      }
    }
    if (currentCustomer.getNumberOfItems() > 0){
      currentCustomer.serve();
      itemsServed++;
    }
	if(currentCustomer.getNumberOfItems() == 0){
        customersServed++;
        waitTime += currentTime - currentCustomer.getArrivalTime();
        currentCustomer = null;
      }
  }

  public int getTotalCustomerWaitTime(){
    return waitTime;
  }
  public int getTotalCustomersServed(){
    return customersServed;
  }
  public int getTotalItemsServed(){
    return itemsServed;
  }
  public String toString(){
    return "Total Wait Time: " + waitTime + "\nCustomers Served: "+ customersServed + "\nTotal Items Served: " + itemsServed;

  }
}
