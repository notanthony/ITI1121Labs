Student name: Anthony Zhao
Student number: 300130883
Course code: ITI1121
Lab section: C-4

This archive contains the 5 files of lab 8, that is, this file (README.txt),
plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.