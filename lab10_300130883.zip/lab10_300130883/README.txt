Student name: Anthony Zhao
Student number: 300130883
Course code: ITI1121
Lab section: C-4

This archive contains the 3 files of lab 10, that is, this file (README.txt),
plus OrderedStructure.java, OrderedList.java.