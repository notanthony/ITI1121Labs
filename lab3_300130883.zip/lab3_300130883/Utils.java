/**
 * this class only contains the method findAndReplace which returns a copy of the given array
 * with all the words in a "query" array replaced with the corresponding word in a "replacement" array
 * @author Anthony Zhao
 */

public class Utils {

    /**
     * Returns a copy of the array 'in' where each word occurring in the array
     * 'what' has been replaced by the word occurring in the same position
     * in the array 'with'.
     *
     * @param in an array of Strings;
     * @param what an array of words to be replaced;
     * @param with an array of replacement words;
     * @return a new array idententical to 'in' except that all the occurrences of words
     * found in 'what' have been replaced by the corresponding word from 'with'.
     */

    public static String[] findAndReplace( String[] in, String[] what, String[] with ) {
        String[] out = null; 
      	if ( in == null || what == null || with == null || nullFinder(in)|| nullFinder(what)|| nullFinder(with)||what.length!=with.length) {
      	    return out;
      	}
      	out = new String[ in.length ];
      	for ( int i=0; i<in.length; i++ ) {
			out[i] = in[i];
			for (int x = 0; x<with.length; x++) {
				if (out[i].equals(what[x])) {
					out[i] = with[x];
				} else {
					out[i] = out[i].replace(what[x], with[x]);
				}
			}
      	}
        return out;
    }
	
	private static boolean nullFinder(String[] arr){
		for (String str: arr) {
			if (str == null) {
				return true;
			}
		}
		return false;
	}
}