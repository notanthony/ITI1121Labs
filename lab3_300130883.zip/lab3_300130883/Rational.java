public class Rational {

    private int numerator;
    private int denominator = 1;

    // constructors

    public Rational(int numerator) {
	     this.numerator = numerator;
		 reduce();
    }

    public Rational(int numerator, int denominator) {
	     this.numerator = numerator*denominator/Math.abs(denominator);
		 this.denominator = Math.abs(denominator);
		 reduce();
    }

    // getters

    public int getNumerator() {
	     return numerator;
    }

    public int getDenominator() {
	     return denominator;
    }

    // instance methods

    public Rational plus(Rational other) {
		return new Rational(numerator*other.getDenominator()+other.getNumerator()*denominator, denominator*other.getDenominator());
    }

    public static Rational plus(Rational a, Rational b) {
    	return new Rational(a.getNumerator()*b.getDenominator()+b.getNumerator()*a.getDenominator(), b.getDenominator()*a.getDenominator());
    }

    // Transforms this number into its reduced form

    private void reduce() {
		int divisor = gcd(numerator, denominator);
		numerator /= divisor;
		denominator /= divisor;
    }

    // Euclid's algorithm for calculating the greatest common divisor
    private int gcd(int a, int b) {
		a = Math.abs(a);
		b = Math.abs(b);
    	while (a != b)
    	    if (a > b)
    		     a = a - b;
    	    else
    		     b = b - a;
    	return a;
    }

    public int compareTo(Rational other) {
      if (this.equals(other)) {
		  return 0;
	  }
	  int num = plus(new Rational(-other.getNumerator(), other.getDenominator())).getNumerator();
	  return num/Math.abs(num);
    }

    public boolean equals(Rational other) {
      return other.getNumerator() == numerator && other.getDenominator() == denominator;
    }

    public String toString() {
    	String result = numerator+"/"+denominator;
    	if (denominator == 1) {
    	    result = Integer.toString(numerator);
    	}
    	return result;
    }

}