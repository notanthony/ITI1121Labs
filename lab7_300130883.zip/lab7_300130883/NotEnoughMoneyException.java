public class NotEnoughMoneyException extends IllegalStateException{
	private double balance;
	private double withDrawAmount;
	private double missingAmount;
	public NotEnoughMoneyException(double drawMoney, double balance){
		super("you do not have enough to withdraw "+ drawMoney);
		withDrawAmount = drawMoney;
		missingAmount = drawMoney - balance;
	}
	public double getBalance(){
		return balance;
	}
	public double getAmount(){
		return withDrawAmount;
	}
	public double getMissingAmount(){
		return missingAmount;
	}
}