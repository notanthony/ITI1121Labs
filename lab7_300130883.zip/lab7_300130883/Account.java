public class Account{
	private double balance;
	public Account(){
		this.balance = 0;
	}
	public void withdraw(double drawMoney){
		if(drawMoney>balance){
			throw new NotEnoughMoneyException(drawMoney, balance);
		}
		balance -= drawMoney;
	
	}
	public void deposit(double depoMoney){
		balance += depoMoney;
	}
	public double getBalance(){
		return balance;
	}
}