import java.util.*;
public class Dictionary implements Map<String, Integer> {

    private final static int INITIAL_CAPACITY = 10;
    private final static int INCREMENT = 5;
    private int count;

    private Pair[] elems;

    public int getCount() {
      return count;
    }

    public int getCapacity() {
      return elems.length;
    }

    public Dictionary() {
        elems = new Pair[INITIAL_CAPACITY];
		count = 0;
    }

    @Override
    public void put(String key, Integer value) {
		if(key == null||value == null){
			throw new NullPointerException("key or value is null");
		}
        elems[count++] = new Pair(key, value);
		if (count == elems.length){
			increaseCapacity();
		}
    }

    private void increaseCapacity() {
        Pair[] newElems = new Pair[elems.length+INCREMENT];
		for (int x = 0; x < elems.length; x++) {
			newElems[x] = elems[x];
		}
		elems = newElems;
    }

    @Override
    public boolean contains(String key) {
			if (key == null){
			throw new NullPointerException("key is null");
		}
        for (Pair p: elems) {
			if(p != null && p.getKey().equals(key)) 
				return true;
		}
		return false;
    }

    @Override
    public Integer get(String key) {
		if (key == null){
			throw new NullPointerException("key is null");
		}
		if(!contains(key)){
			throw new NoSuchElementException("non-existent key");
		}
        for (int x = count-1; x >=0; x--) {
			Pair p = elems[x];
			if(p != null && p.getKey().equals(key)) 
				return p.getValue();
		}
		return null;
    }

    @Override
    public void replace(String key, Integer value) {
		if(key == null || value == null){
			throw new NullPointerException("key or value is null");
		}
		if(!contains(key)){
			throw new NoSuchElementException("non-existent key");
		}
        for (int x = count-1; x >=0; x--) {
			Pair p = elems[x];
			if(p != null && p.getKey().equals(key)) 
				p.setValue(value);
		}
    }

    @Override
    public Integer remove(String key) {
		if (key == null){
			throw new NullPointerException("key is null");
		}
		if(!contains(key)){
			throw new NoSuchElementException("non-existent key");
		}
		Integer returned = 0;
		for (int x = count-1; x >=0; x--) {
			Pair p = elems[x];
			if (p != null && p.getKey().equals(key)) {
				returned = p.getValue();
				elems[x] = null;
				count--;
				break;
			}
		}
		return returned;
    }

    @Override
    public String toString() {
      String res;
      res = "Dictionary: {elems = [";
      for (int i = count-1; i >= 0 ; i--) {
          res += elems[i];
          if(i > 0) {
              res += ", ";
          }
      }
      return res +"]}";
    }

}