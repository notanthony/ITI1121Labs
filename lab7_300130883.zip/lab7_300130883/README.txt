Student name: Anthony Zhao
Student number: 300130883
Course code: ITI1121
Lab section: C-4

This archive contains the 11 files of lab 7, that is, this file (README.txt),
plus Exercise1.java, Account.java, NotEnoughMoneyException.java, Stack.java, ArrayStack.java, DynamicArrayStack.java, FullStackException.java, Map.java, Dictionary.java, Pair.java.
