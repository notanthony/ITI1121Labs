public class FullStackException extends Exception{
	public FullStackException(){
		super("Full stack");
	}
	public FullStackException(String message){
		super(message);
	}
	}