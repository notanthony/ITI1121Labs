Student name: Anthony Zhao
Student number: 300130883
Course code: ITI1121
Lab section: C-4

This archive contains the 3 files of the lab 2, that is, this file (README.txt),
plus the files Combination.java and DoorLock.java.