import java.util.*;
public class Combination {


	private final int[] LOCK_COMBINATION = new int[3];
   
    public Combination( int first, int second, int third ) {
        LOCK_COMBINATION[0] = first;
		LOCK_COMBINATION[1] = second;
		LOCK_COMBINATION[2] = third;
    }

    public boolean equals( Combination other ) {
        return !(other == null) && toString().equals(other.toString());
    }

    public String toString() {
        return Arrays.toString(LOCK_COMBINATION).replace(", ",":").replace("[","").replace("]","");
    }

}